import pathlib
import yaml

for path in sorted(pathlib.Path('k8s').glob('*.yaml')):
    with path.open('r', encoding='utf-8') as handle:
        yaml.safe_load(handle)
    print(f'validated {path}')
