#!/usr/bin/env bash
set -euo pipefail

# This script performs repeated health checks until the endpoint becomes healthy or the retry budget is exhausted.

URL="${1:-http://127.0.0.1:8080/healthz}"
MAX_ATTEMPTS="${2:-12}"
SLEEP_SECONDS="${3:-10}"

for ATTEMPT in $(seq 1 "$MAX_ATTEMPTS"); do
  echo "Running health check $ATTEMPT/$MAX_ATTEMPTS against $URL"
  if curl -fsS "$URL" > /tmp/health-check.json; then
    echo "Health check passed"
    cat /tmp/health-check.json
    exit 0
  fi
  if [[ "$ATTEMPT" -lt "$MAX_ATTEMPTS" ]]; then
    sleep "$SLEEP_SECONDS"
  fi
done

echo "Health check failed after $MAX_ATTEMPTS attempts" >&2
exit 1
