# Deployment pipeline enhancements

## SDLC Phase 4: Deployment & Release

This pipeline now includes production-grade release controls that support safe deployment and fast recovery.

### Blue-Green Deployment
- Used during deployment rollout when a new version should be validated before traffic shifts.
- The workflow promotes the new image to a second target state and only switches traffic after health verification succeeds.
- Benefit: low-risk releases and fast rollback.

### Canary Deployment
- Used when the team wants to expose a small percentage of traffic to the new build before full rollout.
- The workflow annotates the ingress to direct a small share of requests to the canary release.
- Benefit: reduced blast radius and easier detection of regressions.

### Health Checks
- Used after each rollout to verify application readiness and survival.
- The Flask app exposes /healthz, which the workflow queries before proceeding.
- Benefit: prevents unhealthy versions from receiving traffic.

### Deployment Verification
- Used as a release gate before the deployment is considered successful.
- The workflow validates rollout status, pod readiness, and the health endpoint.
- Benefit: ensures only verified artifacts reach production.

### Automatic Rollback
- Used when the health check or verification step fails.
- The workflow calls the rollback script to undo the deployment and restore the previous service state.
- Benefit: limits downtime and protects availability.
