#!/usr/bin/env bash
set -euo pipefail

# This script performs an automatic rollback by undoing the latest rollout and restoring the previous deployment state.

NAMESPACE="${1:-default}"
DEPLOYMENT_NAME="${2:-flask-copilot-demo}"
SERVICE_NAME="${3:-flask-copilot-demo}"

echo "Rolling back deployment $DEPLOYMENT_NAME in namespace $NAMESPACE"

kubectl rollout undo deployment/"$DEPLOYMENT_NAME" -n "$NAMESPACE" || true
kubectl rollout status deployment/"$DEPLOYMENT_NAME" -n "$NAMESPACE" --timeout=300s || true
kubectl patch service "$SERVICE_NAME" -n "$NAMESPACE" --type='merge' -p '{"spec":{"selector":{"app-color":"blue"}}}' || true
