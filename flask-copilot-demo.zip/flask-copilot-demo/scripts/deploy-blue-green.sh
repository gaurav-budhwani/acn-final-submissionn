#!/usr/bin/env bash
set -euo pipefail

# This script performs a blue-green deployment by switching the service selector to the new release color.
# The deployment must already have an app-color label so the service can target the active color.

IMAGE="${1:-}"
NAMESPACE="${2:-default}"
DEPLOYMENT_NAME="${3:-flask-copilot-demo}"
SERVICE_NAME="${4:-flask-copilot-demo}"

if [[ -z "$IMAGE" ]]; then
  echo "An image reference is required." >&2
  exit 1
fi

# Determine the current active color from the deployment label.
CURRENT_COLOR="$(kubectl get deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" -o jsonpath='{.metadata.labels.app-color}' 2>/dev/null || true)"
if [[ -z "$CURRENT_COLOR" ]]; then
  CURRENT_COLOR="blue"
fi

# Switch to the opposite color for the new rollout.
if [[ "$CURRENT_COLOR" == "blue" ]]; then
  TARGET_COLOR="green"
else
  TARGET_COLOR="blue"
fi

echo "Deploying image $IMAGE to $TARGET_COLOR in namespace $NAMESPACE"

# Update the deployment image and ensure the pod template carries the target color label.
kubectl set image deployment/"$DEPLOYMENT_NAME" "$DEPLOYMENT_NAME"="$IMAGE" -n "$NAMESPACE"
kubectl label deployment/"$DEPLOYMENT_NAME" app-color="$TARGET_COLOR" --overwrite -n "$NAMESPACE"
kubectl patch deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" --type='merge' -p "{\"spec\":{\"template\":{\"metadata\":{\"labels\":{\"app-color\":\"$TARGET_COLOR\"}}}}}"

# Wait for the rollout to finish before switching traffic.
kubectl rollout status deployment/"$DEPLOYMENT_NAME" -n "$NAMESPACE" --timeout=300s

# Point the Service at the new color.
kubectl patch service "$SERVICE_NAME" -n "$NAMESPACE" --type='merge' -p "{\"spec\":{\"selector\":{\"app-color\":\"$TARGET_COLOR\"}}}"
