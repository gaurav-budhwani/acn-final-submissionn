from app import app


def test_home_endpoint_returns_healthy_status():
    client = app.test_client()
    response = client.get("/")

    assert response.status_code == 200
    assert response.get_json()["status"] == "healthy"
    assert response.get_json()["message"] == "Deployment successful"


def test_health_endpoint_returns_ok():
    client = app.test_client()
    response = client.get("/healthz")

    assert response.status_code == 200
    assert response.get_json()["status"] == "ok"
