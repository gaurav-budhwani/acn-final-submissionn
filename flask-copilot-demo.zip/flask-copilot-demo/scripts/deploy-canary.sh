#!/usr/bin/env bash
set -euo pipefail

# This script performs a canary rollout by updating the existing deployment and annotating the ingress.
# The ingress controller must support canary routing annotations such as the NGINX ingress controller.

IMAGE="${1:-}"
NAMESPACE="${2:-default}"
DEPLOYMENT_NAME="${3:-flask-copilot-demo}"
INGRESS_NAME="${4:-flask-copilot-demo}"

if [[ -z "$IMAGE" ]]; then
  echo "An image reference is required." >&2
  exit 1
fi

echo "Starting canary release for $DEPLOYMENT_NAME in namespace $NAMESPACE"

# Roll out the new image with a canary label so the release can be identified separately.
kubectl set image deployment/"$DEPLOYMENT_NAME" "$DEPLOYMENT_NAME"="$IMAGE" -n "$NAMESPACE"
kubectl label deployment/"$DEPLOYMENT_NAME" canary=true --overwrite -n "$NAMESPACE"
kubectl patch deployment "$DEPLOYMENT_NAME" -n "$NAMESPACE" --type='merge' -p '{"spec":{"template":{"metadata":{"labels":{"canary":"true"}}}}}'

# Wait for the canary pods to become ready.
kubectl rollout status deployment/"$DEPLOYMENT_NAME" -n "$NAMESPACE" --timeout=300s

# Route a small percentage of traffic to the canary release.
kubectl annotate ingress "$INGRESS_NAME" nginx.ingress.kubernetes.io/canary="true" nginx.ingress.kubernetes.io/canary-weight="10" --overwrite -n "$NAMESPACE"
