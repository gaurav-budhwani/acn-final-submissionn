import os

from flask import Flask, jsonify

app = Flask(__name__)


@app.get("/")
def home():
    return {
        "status": "healthy",
        "message": "Deployment successful",
    }


@app.get("/healthz")
def healthz():
    return jsonify({"status": "ok"}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")), debug=False)
